#!/bin/sh
ARCH="x86_64" ./build.sh
ARCH="arm" ./build.sh
ARCH="x86" ./build.sh
ARCH="arm64" ./build.sh
